package com.example.ella.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.widget.RatingBar;
import android.widget.TextView;

/**
 * Created by ella on 04/01/17.
 */

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        RatingBar bar = (RatingBar)findViewById(R.id.ratingBar1);
        bar.setNumStars(5);
        bar.setStepSize(0.5f);
        TextView t = (TextView)findViewById(R.id.textResult);
        Bundle b = getIntent().getExtras();
        int score = b.getInt("score");
        bar.setRating(score);
        switch (score){
            case 1:
            case 2: t.setText("Better luck next time!");
            break;
            case 3:
            case 4: t.setText("Hmm..");
                break;
            case 5: t.setText("Trivia wizard!");
                break;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.activity_result, menu);
        return true;
    }
}
