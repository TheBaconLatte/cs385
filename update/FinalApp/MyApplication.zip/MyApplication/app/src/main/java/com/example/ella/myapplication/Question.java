package com.example.ella.myapplication;

/**
 * Created by ella on 04/01/17.
 */

public class Question {
    private int ID;
    private String QUESTION;
    private String OPTA;
    private String OPTB;
    private String OPTC;
    private String ANSWER;
    public Question(){
        ID = 0;
        QUESTION = "";
        OPTA = "";
        OPTB = "";
        OPTC = "";
        ANSWER = "";
    }
    public Question(String qs, String oa, String ob, String oc, String ans){
        QUESTION = qs;
        OPTA = oa;
        OPTB = ob;
        OPTC = oc;
        ANSWER = ans;
    }
    public int getID(){
        return ID;
    }
    public String getQUESTION(){
        return QUESTION;
    }
    public String getOPTA(){
        return OPTA;
    }
    public String getOPTB(){
        return OPTB;
    }
    public String getOPTC(){
        return OPTC;
    }
    public String getANSWER(){
        return ANSWER;
    }
    public void setID(int id){
        ID = id;
    }
    public void setQUESTION(String qs){
        QUESTION = qs;
    }
    public void setOPTA(String oa){
        OPTA = oa;
    }
    public void setOPTB(String ob){
        OPTB = ob;
    }
    public void setOPTC(String oc){
        OPTC = oc;
    }
    public void setANSWER(String ans){
        ANSWER = ans;
    }
}
